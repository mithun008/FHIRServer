var express = require('express');
var router = express.Router();
const request = require('request');
var clientsData = require('../db/FHIRPatientData.json');
var patientdata = require('../db/FHIRPatient.json');
var fhirobservation = require('../db/FHIRObservation.json');
var authcognito = require('../public/js/AuthCognito.js');

//Amazon Cognito imports
const AmazonCognitoIdentity = require('amazon-cognito-identity-js');
const CognitoUserPool = AmazonCognitoIdentity.CognitoUserPool;
const AWS = require('aws-sdk');

const jwkToPem = require('jwk-to-pem');
const jwt = require('jsonwebtoken');
global.fetch = require('node-fetch');


var Datastore = require('nedb');
var db = new Datastore();


var refobsid = 1;

/* GET home page. */
router.get('/', function(req, res, next) {
    console.log("req1" + req.query.id);
    refobsid = req.query.id;
    res.render('Observation', { title: 'Patient Observation', obsid: req.query.id });
});

/* GET home page. */
router.get('/Data/', function(req, res, next) {
    console.log("refobsid" + refobsid);
    console.log("test" + refobsid);

    //u
    //get token 
    //use token
    
    authcognito.token().then(function(respromise) {
        token = respromise;

        console.log("THIS IS THE TOKEN" + token);
   
        //TODO: Change the options with url of your FHIR Server
   
        var options = {
            url: "https://h4awl8tfn4.execute-api.us-west-2.amazonaws.com/Prod/Observation?patient-ref-id=" + refobsid,
            host: "h4awl8tfn4.execute-api.us-west-2.amazonaws.com",
            path: "Prod/Observation",
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Authorization": token
            }
        }

        //let url = `https://h4awl8tfn4.execute-api.us-west-2.amazonaws.com/Prod/Patient`

        request(options, function(err, response, body) {
            if (err) {
                console.log("In error  ");
                console.log(err);

            }
            else {
                let patientlist = JSON.parse(body);
                //var pl = list<FHIRPatient>
                console.log(patientlist);
                // pl =   patientlist["entry"][1];
                //console.log(FHIRPatient);
                //console.log("patientlsit + " + FHIRPatient.resource.name[0].family);
                res.json(patientlist["entry"]);
            }
        });


    });

    // let url = "https://h4awl8tfn4.execute-api.us-west-2.amazonaws.com/Prod/Observation?patient-ref-id=" +refobsid 
    // request(url, function(err, response, body) {
    //     if (err) {
    //         console.log("In error  ");
    //     }
    //     else {
    //         let patientlist = JSON.parse(body);
    //         //var pl = list<FHIRPatient>

    //         // pl =   patientlist["entry"][1];
    //         //console.log(FHIRPatient);
    //         //console.log("patientlsit + " + FHIRPatient.resource.name[0].family);
    //         res.json(patientlist["entry"]);
    //     }
    // });
    // res.json(patientlist);

});

module.exports = router;
