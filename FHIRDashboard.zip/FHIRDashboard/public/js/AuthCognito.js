const AmazonCognitoIdentity = require('amazon-cognito-identity-js');
const CognitoUserPool = AmazonCognitoIdentity.CognitoUserPool;
const AWS = require('aws-sdk');
const request = require('request');
const jwkToPem = require('jwk-to-pem');
const jwt = require('jsonwebtoken');
global.fetch = require('node-fetch');

const poolData = {
    UserPoolId: "us-west-2_33hl8izuu", //TODO: Your user pool id here    
    ClientId: "5bc8mkip7uo5lbdbg6qhdduba9" //TODO: Your client id here
};
const pool_region = 'us-west-2';//TODO: Select the region of your AWS conginto User Pool

const userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
var methods = {};




var token = function() {
    return new Promise(function(resolve, reject) {

//TODO: Change the username and password

        var authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails({
            Username: 'navneets',
            Password: 'Test123!',
        });

        var userData = {
            Username: 'navneets',
            Pool: userPool
        };
        var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
        cognitoUser.authenticateUser(authenticationDetails, {
            onSuccess: function(result) {
                // console.log('access token + ' + result.getAccessToken().getJwtToken());
                // console.log('id token + ' + result.getIdToken().getJwtToken());
                // console.log('refresh token + ' + result.getRefreshToken().getToken());

                resolve(result.getIdToken().getJwtToken());
                //return result.getAccessToken().getJwtToken();

            },
            onFailure: function(err) {
                console.log(err);
                reject("");
            },

        });

    });
}

exports.token = token;
//exports.data = methods;